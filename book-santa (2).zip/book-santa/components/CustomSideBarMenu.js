import React, { Component } from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { DrawerItems } from 'react-navigation-drawer';
import Firebase from 'firebase';

export default class CustomSideBarMenu extends Component {
  render() {
    return (
      <View style={Styles.container}>
      <View style={Styles.drawerItemsContainer}>
      <DrawerItems {...this.props}/>
      </View>
      </View>
    );
  }
}

var style = StyleSheet.create({
  container: {
    flex: 1
  },
  drawerItemsContainer: {
    flex: 0.8
  },
  logoutContainer: {
    flex: 0.2,
    justifyContent: 'flex-end',
    paddingBottom: 30
  },
  logoutButton: {
    height: 30,
    width: '100%',
    justifyContent: 'center',
    padding: 10
  },
  logoutText: {
    fontSize: 30,
    fontWeight: 'bold'
  }
});